/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

/**
 *
 * @author huyle
 */
public class Luong {
    private NhanVien nv;
    private final String maNV;
    private int luongCB, ngayCong, phuCap;
    private long tongLuong;

    public Luong(NhanVien nv) {
        this.nv = nv;
        this.maNV = nv.getMaNV();
        this.ngayCong = 0;
        setLuongCB();
        setPhuCap();
        this.tongLuong = tinhTongLuong();
    }

    public int getLuongCB() {
        return luongCB;
    }
    
    public NhanVien getNV() {
        return nv;
    }
    
    public void setLuongCB() {
        if (nv.getChucVu().trim().equals("Chuyen vien")) {
            this.luongCB = 100000;
        } else if (nv.getChucVu().trim().equals("Truong phong")) {
            this.luongCB = 250000;
        } else {
            this.luongCB = 400000;
        }
    }

    public void setLuongCB(int n) {
        this.luongCB = n;
    }
    
    public int getPhuCap() {
        return phuCap;
    }

    public void setPhuCap() {
        if (nv.getChucVu().trim().equals("Chuyen vien")) {
            this.phuCap = 150000; 
        } else if (nv.getChucVu().trim().equals("Truong phong")) {
            this.phuCap = 250000;
        } else {
            this.phuCap = 300000;
        }
    }

    public void setPhuCap(int n) {
        this.phuCap = n;
    }

    public int getNgayCong() {
        return ngayCong;
    }

    public void setNgayCong(int ngayCong) {
        this.ngayCong = ngayCong;
    }

    public long setTongLuong(long tongLuong) {
        return this.tongLuong = tongLuong;
    }

    public long getTongLuong() {
        return tongLuong;
    }

    public long tinhTongLuong() {
        return luongCB * ngayCong + phuCap;
    }

    @Override
    public String toString() {
        return nv + " " + " " + luongCB + " " + ngayCong + " " + phuCap + " " + tongLuong;
    }

    public String getMaNV() {
        return this.maNV;
    }
}
